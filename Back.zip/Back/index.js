const express = require('express');
const app = express();
require('./config');
const route = require('./routes/student_route');
app.use(express.json()); 
app.use('/uploaded/images', express.static('./uploaded/images'));
app.use('/student', route);
app.listen(4080, () =>{
    console.log("Server connected successfully!")
});