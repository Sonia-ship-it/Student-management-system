const mongoose = require('mongoose');
const studentSchema = new mongoose.Schema({
    "name": {
        type: String,
        required: [true, "Please enter your names"]
    },
    "age": Number,
    "grade":  Number,
    "image": String
});
const Student = new mongoose.model('student', studentSchema);
module.exports = Student;
