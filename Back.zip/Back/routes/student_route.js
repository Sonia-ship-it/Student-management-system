const express = require('express');
const router = express.Router();
const studentController = require('../controllers/student_controllers');
const upload = require('../upload');
router.post('/create', upload.single('image'), studentController.createStudent);                                                                     
router.get('/:id', studentController.readStudent);    
router.patch('/update/:id', studentController.updateStudent);
router.delete('/delete/:id', studentController.deleteStudent);
module.exports = router;