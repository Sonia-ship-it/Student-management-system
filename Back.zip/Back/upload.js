const fs = require('fs');
const path = require('path');
const uploadDir = path.join(__dirname, '/uploaded/images');
if(!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true})
}
const multer = require('multer');
const storage = multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, cb) => {
        return cb(null, `${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`);
    }
})
const upload = multer({ storage: storage});
module.exports = upload;