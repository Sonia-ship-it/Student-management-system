const Student = require('../models/student_models');

exports.createStudent = async(req, res) => {
    const { name, age, grade} = req.body;
    if(!req.file) {
       return res.status(404).send("file not found\n upload your image");
    }
 try  {
  const newStudent =   await  Student.create({
        name,
        age,
        grade,
      image: req.file.path
    });
    res.status(201).json({ 
        message: "Created successfully",
       student: newStudent
    });
} catch (error) {
    res.status(500).json({message: error.message})
}
}
exports.readStudent = async(req, res) => {
    const id = req.params.id;
    try  {
       const students =  await  Student.findById(id);
        res.status(200).json(students);
        console.log("Seen");
    } catch (error) {
        res.status(500).json({message: error.message})
    } 
}
exports.updateStudent = async(req, res) => {
    try {
        const id = req.params.id;
    const { name, age, grade} = req.body;
        const updatedData = {
            name,
            age,
            grade,
        }
        if(req.file) {
            updatedData.image= req.file.path
        }
        const student = await Student.findById(id);
        if(!student) {
            res.status(404).json({ message: "Student not found"});
        }
        const updated = await Student.findOneAndUpdate({ _id: id }, updatedData, { new: true, runValidators: true});
        res.status(200).send(updated);
    }
    catch(error) {
        res.status(500).json({ message: error.message});
    }
}
exports.deleteStudent = async(req, res) => {
    const id = req.params.id;
    const student = await Student.findById(id);
    if(!student) {
        res.status(404).json({ message: "Student not found"});
    }
    try{
        await Student.findByIdAndDelete(id);
        res.status(201).send("Student deleted successful");
    }
    catch{
        res.status(500).json({ message: error.message});
    }
}